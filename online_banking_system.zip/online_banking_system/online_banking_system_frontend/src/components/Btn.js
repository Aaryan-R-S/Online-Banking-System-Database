import React, {useState} from 'react';
import {
	Link
  } from "react-router-dom";

export default function Btn(props) {

	const [active, setactive] = useState([null,null])

	const change_b=()=>{
			setactive([null,"active"])
			props.business_button()
	}

	const change_a=()=>{
			setactive(["active",null])
			props.personal_button()
	}


  return (
    <>
	<ul className="nav nav-pills">
		<li className="nav-item">
			<Link className={`nav-link ${active[0]}`} onClick={change_a}  to="/">Personal Customer</Link>
		</li>
		<li className="nav-item">
			<Link className={`nav-link ${active[1]}`} onClick={change_b} to="/">Business Customer</Link>
		</li>
	</ul>
    </>
  )
}
