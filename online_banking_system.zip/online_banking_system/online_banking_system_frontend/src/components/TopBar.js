import React from 'react'

export default function TopBar() {
  return (
    <div>
        <nav className="navbar navbar-light bg-primary pad_bottom">
            <div className="container-fluid">
                <a className="navbar-brand text-light" href="/">
                Blue-Bank NetBanking
                </a>
            </div>
        </nav>
    </div>
  )
}
