import './App.css';
import Btn from './components/Btn';
import TopBar from './components/TopBar';
import React, { useState} from 'react';
import {
	Switch,
	Route
  } from "react-router-dom";

function App(){

  const [whichUser, setwhichUser] = useState(0)

  const personal_button=()=>{
	console.log("Hlo personal user")
	setwhichUser(1)
	// context.router.push("/LoginForm")
	// props.history.push('/LoginForm')
  }
  
  const business_button=()=>{
	console.log("Hlo business user")
	setwhichUser(2)
}

	const [data, setdata] = useState({})
  let response={}
  const handleSubmit = async(e)=> {
    e.preventDefault();
    const data = handleValue();
    console.log('submit');
    console.log(data);
    await fetch('http://localhost:5000/api/', {
    //   mode: 'no-cors',
      method: 'POST',
      headers: {
		'Content-type': 'application/json'
      },
      body: JSON.stringify(data),
    })
      .then(res => res.json())
      .then(res => {response=res})
	  setdata(response)
  }

 
  function handleValue() {
	return({
		"type":whichUser,
		"login":{
			"id":document.getElementById("userID").value,
			"pwd":document.getElementById("password").value
    }
	})
  }


  return (
    <>
		<TopBar/>
		<div className="fm">
		<h4>Welcome Blue-Bank NetBanking</h4>
		</div>
		<div className='"row"'>
			<div className='col'>
				<div className="container">
					<Switch>
						<Route exact path="/">
						<Btn personal_button={personal_button} business_button={business_button} />
						</Route>
						{/* <Route exact path="/PersonalLoginForm">
						</Route>
						<Route exact path="/BusinessLoginForm">
						</Route> */}
					</Switch>
				</div>
				<div className="fm">
				<form>
					<div className="mb-3">
						<label htmlFor="exampleInputEmail1" className="form-label">Login User-ID</label>
						<input type="number" className="form-control" id="userID" aria-describedby="emailHelp"/>
					</div>
					<div className="mb-3">
						<label htmlFor="exampleInputPassword1" className="form-label">Login Password</label>
						<input type="password" className="form-control" id="password"/>
					</div>
					<button type="submit" className="btn btn-primary" onClick={handleSubmit}>Submit</button>
				</form>
				</div>
			</div>
			<div className='col'>
				<p>Profile Details are:</p>
				{Object.entries(data).map(([key, value]) => (
					<p key={key}>{key}: {value}</p>
				))}
			</div>
		</div>
    </>
  )
}

export default App;


//	FOR data from python to reactt
//   useEffect(() => {
//     fetch("/profile").then(
//       res=>res.json()
//     ).then(
//       data=>{
//         setbe(data)
//         console.log(data)
//       }
//     )
//   }, [a])