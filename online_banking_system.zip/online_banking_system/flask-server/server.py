from glob import glob
import json
import profile
import re
from cv2 import recoverPose
from flask import Flask, jsonify, request
from main import *
import time
# from new_input import new_print as print
# from new_input import new_input as input

global pfl
def input_credentials(which=0):
    global record
    login_id = record["login"]["id"]
    login_pwd = record["login"]["pwd"]
    if which in [1,2]:
        ret_val = myBf.search_credentials(login_id, login_pwd, which)
        if ret_val != []:
            return ret_val[0][0]
    return -1

def get_personal_customer():
    global pfl
    pc_id = input_credentials(2)
    if pc_id==-1:
        print(errors["incorrect_login"])
    else:
        myPersonalCustomer = pc.PersonalCustomer(myTable,lis,pc_id)
        print(statements["login_success"])
        pfl= myPersonalCustomer.get_profile()


def get_business_customer():
    global pfl
    bc_id = input_credentials(2)
    if bc_id==-1:
        print(errors["incorrect_login"])
    else:
        myBusinessCutomer = bc.BusinessCustomer(myTable,lis,bc_id)
        print(statements["login_success"])
        pfl= myBusinessCutomer.get_profile()


app=Flask(__name__)
# member api route for python to react communication
# @app.route("/profile")
# def members():
#     global pfl
#     return {"profile":pfl}

success_response={"sucess":"query sucessfull"}
global record
@app.route('/api/', methods=['POST'])
def api_post():
    global record
    global pfl
    if request.method == 'POST':
        print('post app')
        record = json.loads(request.data)
        print(record)
        if(record["type"]=="1"):
            get_personal_customer()
        elif(record["type"]=="2"):
            get_business_customer()
        print(pfl)
        return jsonify(pfl)


if __name__=="__main__":
    app.run(debug=True)